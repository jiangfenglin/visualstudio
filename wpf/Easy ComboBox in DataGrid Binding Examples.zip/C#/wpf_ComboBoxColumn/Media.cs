﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf_ComboBoxColumn
{
    public class Media
    {
        public string MediaType { get; set; }
        public string Container { get; set;}
        public double Volume { get; set; }
        public int ColourId { get; set;}
    }
}
