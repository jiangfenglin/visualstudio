﻿
namespace EasyWpfLoginNavigateExample.Model
{
    public enum ApplicationPage
    {
        NewControl1,
        NewWindow2,
    }
}
