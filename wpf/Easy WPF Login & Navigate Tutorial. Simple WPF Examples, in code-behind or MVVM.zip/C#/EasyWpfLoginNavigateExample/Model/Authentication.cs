﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyWpfLoginNavigateExample.Model
{
    public class Authentication
    {
        public static bool Authenticate1(string UserName, string Password)
        {
            return true; // Do authentication against database, web service, whatever
        }
    }
}
